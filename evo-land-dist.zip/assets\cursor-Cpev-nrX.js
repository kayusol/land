import{w as o}from"./core-CVgmEB7S.js";import"./index-DfWHrKtP.js";import"./events-DhkIKIZE.js";import"./index.es-CgSqjVFr.js";import"./index-nibyPLVP.js";const l=o` <svg fill="none" viewBox="0 0 13 4">
  <path fill="currentColor" d="M.5 0h12L8.9 3.13a3.76 3.76 0 0 1-4.8 0L.5 0Z" />
</svg>`;export{l as cursorSvg};
